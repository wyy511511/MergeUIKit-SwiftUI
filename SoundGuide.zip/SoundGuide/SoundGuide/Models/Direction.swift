//
//  Direction.swift
//  SoundGuide
//
//  Created by Zef Houssney on 10/20/22.
//

import SwiftUI

enum Direction: String, CaseIterable {
    case north = "N"
    case northEast = "NE"
    case east  = "E"
    case southEast = "SE"
    case south = "S"
    case southWest = "SW"
    case west  = "W"
    case northWest = "NW"

    static var cardinal: [Self] = {
        allCases.filter(\.isCardinal)
    }()

    static var ordinal: [Self] = {
        allCases.filter(\.isOrdinal)
    }()

    static var angles: [Angle] = {
        Angle.divisions(divisionCount: allCases.count)
    }()

    var index: Int {
        Self.allCases.firstIndex(of: self) ?? 0
    }

    var angle: Angle {
        Self.angles[index]
    }
    var isCardinal: Bool {
        rawValue.count == 1
    }
    var isOrdinal: Bool {
        rawValue.count == 2
    }
}
