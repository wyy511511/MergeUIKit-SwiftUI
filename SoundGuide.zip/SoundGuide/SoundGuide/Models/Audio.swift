//
//  Audio.swift
//  SoundGuide
//
//  Created by Zef Houssney on 10/20/22.
//

import Foundation
import AudioKit
import AudioKitEX
import SporthAudioKit

class Audio: HasAudioEngine {
    static let player = Audio()

    let engine = AudioEngine()
    let mixer = Mixer()

    var leftChannel = Audio.generator(left: 0.95, right: 0)
    var rightChannel = Audio.generator(left: 0, right: 0.95)

    init() {
        mixer.addInput(leftChannel)
        mixer.addInput(rightChannel)

        leftChannel.start()
        rightChannel.start()
        engine.output = mixer
    }

    static func generator(left: Double, right: Double) -> OperationGenerator {
        OperationGenerator(channelCount: 2) { _ in
            let leftOutput = Operation.sineWave(frequency: 523.25, amplitude: left)
            let rightOutput = Operation.sineWave(frequency: 659.26, amplitude: right)
            return [leftOutput, rightOutput]
        }
    }

    func set(volume: Double, pan: Double) {
        print("setting volume: \(volume), pan: \(pan)")
        mixer.volume = AUValue(volume)
        mixer.pan = AUValue(pan)
    }

    func play() {
        self.start()
    }
}
