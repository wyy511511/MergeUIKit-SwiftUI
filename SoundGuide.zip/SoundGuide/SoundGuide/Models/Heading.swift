//
//  Heading.swift
//  SoundGuide
//
//  Created by Zef Houssney on 10/20/22.
//

import Foundation
import CoreLocation

class Heading: NSObject, ObservableObject, CLLocationManagerDelegate {
    private var locationManager = CLLocationManager()

    static var shared = Heading()
    @Published var hasLocationAccess = false
    @Published var degrees: Double = 0
    @Published var targetHeading: Double = 0 {
        didSet {
            setAudioLevels()
        }
    }
    @Published var isTracking = false

    override init() {
       super.init()
       locationManager.delegate = self
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch locationManager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            hasLocationAccess = true
        case .notDetermined, .restricted, .denied:
            hasLocationAccess = false
        @unknown default:
            hasLocationAccess = false
        }
    }

    func requestAuthorization() {
        locationManager.requestWhenInUseAuthorization()
    }

    func startTracking() {
        locationManager.startUpdatingHeading()
        isTracking = true
    }
    func stopTracking() {
        locationManager.stopUpdatingHeading()
        isTracking = false
    }

    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        self.degrees = newHeading.trueHeading
        setAudioLevels()
    }

    func setAudioLevels() {
        let adjustedTarget = (degrees + targetHeading).truncatingRemainder(dividingBy: 360)
        Audio.player.set(volume: volume(for: adjustedTarget), pan: pan(for: adjustedTarget))
    }

    func pan(for degree: Double) -> Double {
        let overlapRange: Double = 30
        if degree < 180 {
            return 1 - fadeBetween(target: degree, from: 180 - overlapRange, to: 180)
        } else {
            return -1 + fadeBetween(target: degree, from: 180 + overlapRange, to: 180)
        }
    }

    func volume(for degree: Double) -> Double {
        let silentRange: Double = 14

        let left = fadeBetween(target: degree, from: silentRange, to: 180)
        let right = fadeBetween(target: degree, from: 360 - silentRange, to: 180)

        return max(left, right)
    }

    func fadeBetween(target: Double, from: Double, to: Double) -> Double {
        let min = min(from, to)
        let max = max(from, to)

        guard target >= min, target <= max else {
            return 0
        }
        let current = target - min
        let end = max - min

        let percentage = current / end
        if from < to {
            return percentage
        } else {
            return percentage.reversedPercentage
        }
    }
}

extension Double {
    func isWithin(_ range: Double, of target: Double) -> Bool {
        self >= target - range && self <= target + range
    }
    func isBetween(_ range: ClosedRange<Double>) -> Bool {
        (self >= range.lowerBound) && (self <= range.upperBound)
    }
    var reversedPercentage: Double {
        return 1 - self
    }
}

