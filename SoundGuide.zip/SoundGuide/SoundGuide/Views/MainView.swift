//
//  MainView.swift
//  SoundGuide
//
//  Created by Zef Houssney on 10/20/22.
//

import SwiftUI

struct MainView: View {
    @StateObject var heading = Heading.shared

    var body: some View {
        VStack {
            Spacer()
            CompassView()
            Spacer()

            Text("Adjust Target Heading")
            Slider(value: $heading.targetHeading, in: 0...359, step: 1) {
                Text("Target Heading")
            }
            .padding(.horizontal) .padding(.bottom, 44)

            if heading.hasLocationAccess {
                if heading.isTracking {
                    Button("Stop Tracking") {
                        heading.stopTracking()
                    }
                    .buttonStyle(.borderedProminent)
                } else {
                    Button("Start Tracking") {
                        heading.startTracking()
                    }
                    .buttonStyle(.borderedProminent)
                }
            } else {
                Button("Allow Location Access") {
                    heading.requestAuthorization()
                }
                .buttonStyle(.borderedProminent)
            }

            HStack {
                Button("Audio On") {
                    Audio.player.play()
                }
                Button("Audio Off") {
                    Audio.player.stop()
                }
                Button("Set Heading") {
                    heading.targetHeading = 360 - heading.degrees
                }
            }
            .buttonStyle(.bordered)
            .padding(.bottom, 60)
        }
        .environmentObject(heading)
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView(heading: Heading.shared)
    }
}
