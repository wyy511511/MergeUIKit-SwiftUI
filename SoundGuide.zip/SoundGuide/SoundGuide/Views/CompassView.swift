//
//  CompassView.swift
//  SoundGuide
//
//  Created by Zef Houssney on 10/20/22.
//

import SwiftUI

extension Angle {
    static func divisions(divisionCount: Int) -> [Angle] {
        let perDivision = 360/Double(divisionCount)
        return Array(0..<divisionCount).map { index in
            let degrees = Double(index) * perDivision
            return Angle(degrees: degrees)
        }
    }
}

struct AngleMarker: Identifiable {
    var angle: Angle
    var color: Color

    var width: CGFloat
    var height: CGFloat

    var text: String?

    var id: Double {
        angle.degrees
    }

    static var mainMarkers: [AngleMarker] {
        Direction.allCases.map { direction in
            let label = direction.isCardinal ? direction.rawValue : nil
            let width: CGFloat = direction.isCardinal ? 4 : 3
            let height: CGFloat = direction.isCardinal ? 20 : 16
            let color: Color = direction.isCardinal ? .blue : .blue.opacity(0.5)
            return AngleMarker(angle: direction.angle, color: color, width: width, height: height, text: label)
        }
    }

    static var subMarkers: [AngleMarker] {
        Angle.divisions(divisionCount: 8*6).map { degrees in
            AngleMarker(angle: degrees, color: .black.opacity(0.5), width: 2, height: 10)
        }.filter { !Direction.angles.contains($0.angle) }
    }
}

struct CompassView: View {
    @EnvironmentObject var heading: Heading

    let compassSize: CGFloat = 280

    var body: some View {
        VStack {
//            Text(heading.targetHeading.formatted())
            Text(heading.degrees.formatted())
                .font(.headline)
            Capsule()
                .foregroundColor(.red)
                .frame(width: 4, height: 16)
            ZStack {
                markerView(markers: AngleMarker.subMarkers, diameter: compassSize)
                markerView(markers: AngleMarker.mainMarkers, diameter: compassSize)
                markerView(markers: [headingMarker(degrees: heading.targetHeading)], diameter: compassSize + 18*2)
            }
            .rotationEffect(Angle(degrees: heading.degrees))
        }
        .padding()
    }


    func markerView(markers: [AngleMarker], diameter: CGFloat = 100) -> some View {
        ZStack {
            ForEach(markers) { marker in
                ZStack {
                    Capsule()
                        .foregroundColor(marker.color)
                        .frame(width: marker.width, height: marker.height)
                    if let text = marker.text {
                        Text(text)
                            .font(.subheadline).bold()
                            .rotationEffect(-marker.angle)
                            .padding(.top, marker.height + 40)
//                            .opacity(0.5)
                    }
                }
                .padding(.bottom, diameter-marker.height)
                .rotationEffect(marker.angle)

            }
        }
        .frame(width: diameter, height: diameter)
    }

    func headingMarker(degrees: Double) -> AngleMarker {
        AngleMarker(angle: Angle(degrees: degrees), color: .red, width: 8, height: 8)
    }

}

struct CompassView_Previews: PreviewProvider {
    static var previews: some View {
        CompassView()
            .environmentObject(Heading.shared)
    }
}
